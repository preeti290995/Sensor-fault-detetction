# import os
# if __name__ == '__main__':
#     API_KEY = os.getenv('API_KEY',None)
#     ENDPOINT_SCHEMA_URL  = os.getenv('ENDPOINT_SCHEMA_URL',None)
#     API_SECRET_KEY = os.getenv('API_SECRET_KEY',None)
#     BOOTSTRAP_SERVER = os.getenv('BOOTSTRAP_SERVER',None)
#     SECURITY_PROTOCOL = os.getenv('SECURITY_PROTOCOL',None)
#     SSL_MACHENISM = os.getenv('SSL_MACHENISM',None)
#     SCHEMA_REGISTRY_API_KEY = os.getenv('SCHEMA_REGISTRY_API_KEY',None)
#     SCHEMA_REGISTRY_API_SECRET = os.getenv('SCHEMA_REGISTRY_API_SECRET',None)



#     print(API_KEY)



